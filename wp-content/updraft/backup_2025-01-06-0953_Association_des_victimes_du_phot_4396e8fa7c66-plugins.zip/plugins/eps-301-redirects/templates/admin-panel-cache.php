<?php
/**
 *
 * Admin Panel Cache
 *
 * The cache panel widget.
 *
 * @package    EPS 301 Redirects
 * @author     WebFactory Ltd
 */

// include only file
if (!defined('ABSPATH')) {
  die('Do not open this file directly.');
}
?>
