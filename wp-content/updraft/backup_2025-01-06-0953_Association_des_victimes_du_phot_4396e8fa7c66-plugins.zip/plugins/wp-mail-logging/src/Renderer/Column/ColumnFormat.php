<?php

namespace No3x\WPML\Renderer\Column;


abstract class ColumnFormat {
    const SIMPLE = 1;
    const FULL = 2;
}
