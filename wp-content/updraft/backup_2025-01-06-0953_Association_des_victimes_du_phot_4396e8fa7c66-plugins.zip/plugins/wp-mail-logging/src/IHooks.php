<?php
namespace No3x\WPML;

interface IHooks {
    function addActionsAndFilters();
}
